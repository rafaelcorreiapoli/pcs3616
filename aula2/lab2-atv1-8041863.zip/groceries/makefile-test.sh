make fruits.txt vegetables.txt
make groceries.txt
make print
make clean
